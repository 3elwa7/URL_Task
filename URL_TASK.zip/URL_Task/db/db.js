// import mongoose package
const mongoose = require('mongoose')

// declare a Database string URI
const DB_URI = 'mongodb+srv://Ali:01112489730@ali.3owkn.mongodb.net/AliDB?retryWrites=true&w=majority'


const connectDB = mongoose.connect(DB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})


module.exports = connectDB