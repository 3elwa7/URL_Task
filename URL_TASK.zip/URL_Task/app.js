const express = require('express')
const mongoose = require('mongoose')
const Url = require('./models/UrlModel')

mongoose.connect('mongodb+srv://Ali:01112489730@ali.3owkn.mongodb.net/AliDB?retryWrites=true&w=majority',{
useNewUrlParser: true,useUnifiedTopology:true
}
)
const app = express()
app.use(express.json()) 
app.use(express.static('./public'))
app.use('/api/url', require('./routes/url'))

app.use('/', require('./routes/redirect'))



const PORT = process.env.PORT || 5000
app.listen(PORT, console.log(`server started, listening PORT ${PORT}`))