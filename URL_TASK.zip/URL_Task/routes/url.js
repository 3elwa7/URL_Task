const express = require('express')
const validUrl = require('valid-url')
const shortid = require('shortid')
const mongoose = require('mongoose')
const app = express
const router = express.Router()
mongoose.connect('mongodb+srv://Ali:01112489730@ali.3owkn.mongodb.net/AliDB?retryWrites=true&w=majority',{
useNewUrlParser: true,useUnifiedTopology:true
}
)

const Url = require('../models/UrlModel')
const baseUrl = 'http:localhost:5000'
router.post('/shorten', async (req, res) => {
    const {longUrl} = req.body
    //const {longUrl} = req.params.long
    console.log(longUrl)
    if (validUrl.isUri(longUrl)) 
    {
        try 
        {
            let url = await Url.findOne({longUrl})
            console.log(url)
            const urlCode = shortid.generate()
            if (url) 
            {
                res.json(url)
            } 
            else 
            {
                let shortUrl = baseUrl + '/' + urlCode
                url = new Url({
                    urlCode,
                    longUrl,
                    shortUrl,
                 
                })
                await url.save()
                res.json(url)
            }
       }
        // exception handler
        catch (err) 
        {
            console.log(err)
            res.status(500).json('Server Error')
        }
    } 
    else 
    {
        res.status(401).json('Invalid longUrl')
    }
})

module.exports = router