const { Axios, default: axios } = require("axios")
const loadingDOM = document.querySelector('.loading-text')
const takeUrl= async(req,res)=>{
var url = document.querySelector('input').value
// const  {longUrl}= req.body =url
const{ urlCode,longUrl,shortUrl}=await axios.post(`/api/url/shorten${url}`)
loadingDOM.innerHTML=shortUrl
}