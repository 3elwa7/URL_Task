const mongoose = require('mongoose')
const shortid = require('shortid')

// instantiate a mongoose schema
const URLSchema = new mongoose.Schema({
    urlCode:{ 
        type:String,
        
    },
    longUrl:{ 
        type: String,
        require: true,
        trim: true
    },
    shortUrl: {
        type: String,
        require: true,
        default: shortid.generate()
    },
  
})

// create a model from schema and export it
module.exports = mongoose.model('Url', URLSchema)